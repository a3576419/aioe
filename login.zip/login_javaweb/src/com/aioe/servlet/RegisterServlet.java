package com.aioe.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.text.DefaultEditorKit.CutAction;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.aioe.customer.Customer;


public class RegisterServlet extends HttpServlet {
	
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String re_password = request.getParameter("re_password");
		System.out.println("username:"+username+"=====password:"+password+"=====repassword:"+re_password);
		//用户名:^[a-zA-Z]\w{5,15}$   使用正则表达式
		//密码:^(?=.*\d)(?=.*[a-zA-Z])(?=.*[\W_]).{6,15}$
		String u_regex = "^[a-zA-Z]\\w{5,15}$";
//		String u_regex1 = "/^[A-Za-z0-9]+$/";
		String p_regex = "^(?=.*\\d)(?=.*[a-zA-Z])(?=.*[\\W_]).{6,15}$";
		if(!username.matches(u_regex)) {
			response.getWriter().print("<script> alert(\"用户名首位不能为数字,用户名不能包含中文和特殊字符,并且长度必须大于5,少于15位!\"); "
					+ "location.href='register.jsp'</script>");
			return;
		}
//		if(!username.matches(u_regex1)) {
//			response.getWriter().print("<script> alert(\"用户名不能包含中文和特殊字符!\"); "
//					+ "location.href='register.jsp'</script>");
//			return;
//		}
		if(!password.matches(p_regex)) {
			response.getWriter().print("<script> alert(\"密码必须同时包含数字,字母及字符,长度必须大于6,少于15位!\"); "
					+ "location.href='register.jsp'</script>");
			return;
		}
		if(!password.equals(re_password)) {
			response.getWriter().print("<script> alert(\"两次输入密码不一致\"); "
					+ "location.href='register.jsp'</script>");
			return;
		}
		Configuration configuration = new Configuration().configure("/com/aioe/servlet/Hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		String sql = "FROM Customer WHERE username = ?";
		Query query = session.createQuery(sql);
		query.setString(0, username);
		List<Customer> list = query.list();
		String db_username = null;
		for (Customer customer : list) {
			db_username = customer.getUsername();
			System.out.println(customer.getId()+":"+customer.getUsername());
		}
		if(username.equals(db_username)) {
			response.getWriter().print("<script> alert(\"该用户名已存在!\"); "
					+ "location.href='register.jsp'</script>");
		}else {
			Customer customer = new Customer();
			customer.setUsername(username);
			customer.setPassword(password);
			session.save(customer);
			response.getWriter().print("<script> alert(\"注册成功!\"); "
					+ "location.href='login.jsp'</script>");
		}
		
		transaction.commit();
		session.close();
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
