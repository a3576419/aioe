package com.aioe.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.aioe.customer.Customer;

public class GetServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
			

		// 1.加载Hibernate核心配置文件
		Configuration configuration = new Configuration().configure("/com/aioe/servlet/Hibernate.cfg.xml");
		// 2.创建sessionFactory
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		//3.通过SessionFactory获取Session对象
		Session session = sessionFactory.openSession();
		//4.手动开启事务
		Transaction transaction = session.beginTransaction();
		//5.编写代码
		
		String sql = "FROM Customer WHERE username = ?";

		Query query = session.createQuery(sql);
		query.setString(0, username);
		List<Customer> list = query.list();
		String db_username = null;
		String db_password = null;
		for (Customer customer : list) {
			db_username = customer.getUsername();
			db_password = customer.getPassword();
			
			System.out.println(customer.getId()+":"+customer.getUsername()+":"+customer.getPassword());
		}
		if(username.equals(db_username)&&password.equals(db_password)) {
//				
			response.sendRedirect("register.jsp");
		}
		else {
				//response.getWriter().write("alert('审批通过')");
			response.getWriter().print("<script> alert(\"请输入正确的账号和密码!\"); location.href='login.jsp'</script>");
			
			return;
		}
		
		
		// session.saveOrUpdate(customer);

		// 6.事务提交
		transaction.commit();
		// 7.资源释放
		session.close();

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
